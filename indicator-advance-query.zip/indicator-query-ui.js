/* ============================================================================
   indicator-query-ui.js — main-thread integration for the Indicator Advance
   Query feature. Depends on: indicator-query.js, indicator-calculators.js,
   indicator-db.js (already loaded in index.html), and existing app globals:
   allData, CURRENT_DATA_DATE, applyFilters(), FILTER_FIELDS, loadChartSettings().
   ========================================================================= */

// ---------------------------------------------------------------------------
// 1. Settings — mirrors the existing ALERT_SETTINGS_KEY / loadAlertSettings()
//    pattern already in index.html (see line ~21031).
// ---------------------------------------------------------------------------
const INDICATOR_SETTINGS_KEY = "nse_screener_indicator_settings";

function loadIndicatorSettings() {
    try {
        return Object.assign(
            { advancedIndicatorQueryEnabled: false },
            JSON.parse(localStorage.getItem(INDICATOR_SETTINGS_KEY) || "{}"),
        );
    } catch (e) {
        return { advancedIndicatorQueryEnabled: false };
    }
}
function saveIndicatorSettings(settings) {
    try {
        localStorage.setItem(INDICATOR_SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
        console.warn("Could not save indicator settings:", e);
    }
}
function isIndicatorQueryEnabled() {
    return !!loadIndicatorSettings().advancedIndicatorQueryEnabled;
}
function setIndicatorQueryEnabled(enabled) {
    const s = loadIndicatorSettings();
    s.advancedIndicatorQueryEnabled = !!enabled;
    saveIndicatorSettings(s);
}

// Wire into exportSettings()/importSettings(): add ONE line to each —
//   payload.indicator_settings = loadIndicatorSettings();                  // in exportSettings()
//   if (payload.indicator_settings) localStorage.setItem(INDICATOR_SETTINGS_KEY, JSON.stringify(payload.indicator_settings)); // in importSettings()
// (same shape as the existing alert_settings lines right above/below them)

// ---------------------------------------------------------------------------
// 2. In-memory RAW indicator store, populated once the worker finishes.
//    Map<isin, Map<canonicalKey, rawCachedValue>> — rawCachedValue is
//    whatever shape that canonical key stores (array for ema/sma/supertrend/
//    rsi, object for afh/macd/pivottrendline). extractQuerySeries() (from
//    indicator-calculators.js) turns it into a flat number[] at query time.
// ---------------------------------------------------------------------------
let indicatorRawStore = new Map();
let indicatorCanonicalKeys = [];   // as reported by worker DONE.keys
let indicatorQueryFields = [];     // expanded for pills, e.g. adds .line/.signal/.hist, .a/.b
let indicatorEngineReady = false;
let pendingRestoredIndicatorQuery = null;

function getOHLCVSeries(isin, key) {
    const candles = indicatorCandlesCache.get(isin);
    if (!candles || !candles.length) return undefined;
    const field = key === "volume" ? "v" : key;
    return candles.map((c) => c[field]);
}

function getIndicatorSeries(isin, fieldName) {
    const dotIdx = fieldName.lastIndexOf(".");
    const canonicalKey = dotIdx === -1 ? fieldName : fieldName.slice(0, dotIdx);
    const subfield = dotIdx === -1 ? undefined : fieldName.slice(dotIdx + 1);
    const perStock = indicatorRawStore.get(isin);
    const raw = perStock ? perStock.get(canonicalKey) : undefined;
    if (raw === undefined) return undefined;
    return IndicatorCalculators.extractQuerySeries(canonicalKey, subfield, raw);
}

// ---------------------------------------------------------------------------
// 3. Worker lifecycle
// ---------------------------------------------------------------------------
let indicatorWorker = null;
let indicatorRequestId = 0;
// Candles fetched by the worker aren't shipped back to the main thread (see
// worker header) — the main thread fetches them again itself only for the
// OHLCV side of query resolution (open/high/low/close/volume[n]), reusing
// the exact same CHART_CACHE the chart modal and the worker both already
// hit, so this is a cache read, not a fresh network fetch.
const indicatorCandlesCache = new Map();

function getEnabledChartIndicatorKeys() {
    const s = loadChartSettings();
    const keys = [];

    (s.ma || []).forEach((ma) => {
        if (ma.enabled) keys.push(`${ma.type}_${ma.length}_${ma.source}`);
    });

    (s.afh || []).forEach((afh) => {
        if (afh.enabled && afh.length >= 15) keys.push(`afh_${afh.length}`);
    });

    (s.supertrend || []).forEach((st) => {
        if (st.enabled) keys.push(`supertrend_${st.atrLength}_${st.factor}`);
    });

    (s.pivottrendline || []).forEach((pivot) => {
        if (pivot.enabled && pivot.length > 1) {
            keys.push(`pivottrendline_${pivot.length}_high`);
            keys.push(`pivottrendline_${pivot.length}_low`);
        }
    });

    if (s.rsi && s.rsi.enabled) {
        const { length, source, smoothingType, smoothingLength } = s.rsi;
        keys.push(`rsi_${length}_${source}_${smoothingType}_${smoothingLength}`);
        if (smoothingLength > 0 && smoothingType !== "none") {
            keys.push(`rsi_sma_${length}_${source}_${smoothingType}_${smoothingLength}`);
        }
    }

    if (s.macd && s.macd.enabled) {
        const { source, fastLength, slowLength, signalLength, oscMaType, signalMaType } = s.macd;
        keys.push(`macd_${source}_${fastLength}_${slowLength}_${signalLength}_${oscMaType}_${signalMaType}`);
    }

    return [...new Set(keys)];
}

function startIndicatorEngine() {
    if (!isIndicatorQueryEnabled()) return;
    if (indicatorWorker) return; // already running/ran this data-load

    const enabledIndicatorKeys = getEnabledChartIndicatorKeys();
    if (!enabledIndicatorKeys.length) {
        setIndicatorUIState("error", "No chart indicators are enabled — enable some in Chart Settings first");
        return;
    }

    indicatorWorker = new Worker("./helper/indicator-worker.js");
    indicatorWorker.onmessage = handleIndicatorWorkerMessage;
    indicatorWorker.onerror = (err) => {
        console.error("[indicator-worker] fatal error:", err.message);
        setIndicatorUIState("error", err.message);
    };

    setIndicatorUIState("computing", null);

    const isins = allData.map((row) => row["ISIN"]).filter(Boolean);
    const chartBaseUrl = new URL("data/chart/", window.location.href).href;

    const requestId = ++indicatorRequestId;
    indicatorWorker.postMessage({
        type: "COMPUTE_INDICATORS",
        requestId,
        isins,
        chartBaseUrl,
        enabledIndicatorKeys,
        dataDate: CURRENT_DATA_DATE,
    });
}

// Called whenever the underlying data changes (new day's m.json, or the
// person changes chart indicator settings) — tears down any running worker
// and starts fresh against the new dataDate / enabled-indicator set.
function restartIndicatorEngine() {
    if (indicatorWorker) {
        indicatorWorker.terminate();
        indicatorWorker = null;
    }
    indicatorEngineReady = false;
    indicatorRawStore = new Map();
    indicatorCandlesCache.clear();
    startIndicatorEngine();
}

function handleIndicatorWorkerMessage(e) {
    const msg = e.data || {};
    if (msg.requestId !== indicatorRequestId) return;

    if (msg.type === "PROGRESS") {
        setIndicatorUIState("computing", `${msg.done.toLocaleString("en-IN")} / ${msg.total.toLocaleString("en-IN")}`);
        return;
    }
    if (msg.type === "ERROR") {
        console.error("[indicator-worker]", msg.error);
        setIndicatorUIState("error", msg.error);
        return;
    }
    if (msg.type === "DONE") {
        indicatorCanonicalKeys = msg.keys;
        if (msg.errors && msg.errors.length) {
            console.warn(`[indicator-worker] ${msg.errors.length} calc/fetch errors:`, msg.errors.slice(0, 20));
        }
        loadIndicatorDataIntoMemory().then(() => {
            indicatorEngineReady = true;
            indicatorQueryFields = IndicatorCalculators.deriveQueryFieldsFromCanonicalKeys(indicatorCanonicalKeys);
            renderIndicatorPills(indicatorQueryFields);
            setIndicatorUIState("ready", `${indicatorQueryFields.length} fields · ${msg.count.toLocaleString("en-IN")} stocks`);
            if (pendingRestoredIndicatorQuery) {
                setIndicatorQueryText(pendingRestoredIndicatorQuery);
                pendingRestoredIndicatorQuery = null;
                applyFilters();
            }
        });
    }
}

// Pull everything the worker just cached back out of IndexedDB into memory
// (raw shapes, not pre-flattened), plus each stock's candle array (needed
// for OHLCV fields in the query and cheap since it's already CHART_CACHE'd).
async function loadIndicatorDataIntoMemory() {
    indicatorRawStore = new Map();
    for (const row of allData) {
        const isin = row["ISIN"];
        if (!isin) continue;

        const perStock = new Map();
        for (const key of indicatorCanonicalKeys) {
            const raw = await IndicatorCacheDB.get(isin, key, CURRENT_DATA_DATE);
            if (raw) perStock.set(key, raw);
        }
        if (perStock.size) indicatorRawStore.set(isin, perStock);

        if (!indicatorCandlesCache.has(isin)) {
            try {
                const res = await fetch(`data/chart/${isin}.json`, { cache: "force-cache" });
                if (res.ok) indicatorCandlesCache.set(isin, await res.json());
            } catch { /* OHLCV fields just won't resolve for this stock */ }
        }
    }
}

// ---------------------------------------------------------------------------
// 4. UI state + pills
// ---------------------------------------------------------------------------
function setIndicatorUIState(state, detail) {
    const section = document.getElementById("group_indicator");
    const box = document.getElementById("f_indicator_query");
    const statusEl = document.getElementById("indicatorQueryStatus");
    if (!section) return;

    section.dataset.state = state;
    if (box) box.disabled = state !== "ready";

    if (statusEl) {
        if (state === "computing") statusEl.textContent = `⏳ Calculating indicators… ${detail || ""}`;
        else if (state === "ready") statusEl.textContent = `✓ Ready — ${detail}`;
        else if (state === "error") statusEl.textContent = `⚠ ${detail}`;
        else statusEl.textContent = "";
        statusEl.className = state === "error" ? "adv-query-status adv-query-err"
            : state === "ready" ? "adv-query-status adv-query-ok"
            : "adv-query-status";
    }
}

function renderIndicatorPills(fields) {
    const container = document.getElementById("indicatorPillList");
    if (!container) return;
    container.innerHTML = "";
    fields.forEach((field) => {
        const pill = document.createElement("button");
        pill.type = "button";
        pill.className = "btn-adv-token indicator-pill";
        pill.textContent = field;
        pill.addEventListener("click", () => insertIndicatorFieldAtCursor(field));
        container.appendChild(pill);
    });
}

function insertIndicatorFieldAtCursor(field) {
    const box = document.getElementById("f_indicator_query");
    if (!box) return;
    const insertText = `${field}[0]`;
    const start = box.selectionStart ?? box.value.length;
    const end = box.selectionEnd ?? box.value.length;
    box.value = box.value.slice(0, start) + insertText + box.value.slice(end);
    const caret = start + insertText.length;
    box.focus();
    box.setSelectionRange(caret, caret);
    onIndicatorQueryInput();
}

// ---------------------------------------------------------------------------
// 5. Validation + application — mirrors advOnQueryInput()/advValidateQuery()
// ---------------------------------------------------------------------------
let indicatorValidateTimer = null;
function onIndicatorQueryInput() {
    clearTimeout(indicatorValidateTimer);
    indicatorValidateTimer = setTimeout(() => {
        validateAndShowIndicatorQuery();
        applyFilters();
    }, 300);
}

function validateAndShowIndicatorQuery() {
    const box = document.getElementById("f_indicator_query");
    const statusEl = document.getElementById("indicatorQueryStatus");
    if (!box || !statusEl) return;
    const text = box.value.trim();
    if (!text) {
        setIndicatorUIState(indicatorEngineReady ? "ready" : "computing", indicatorEngineReady ? `${indicatorQueryFields.length} fields` : null);
        return;
    }
    const result = IndicatorQuery.validateIndicatorQuery(text);
    if (result.ok) {
        statusEl.textContent = "✓ Valid";
        statusEl.className = "adv-query-status adv-query-ok";
    } else {
        statusEl.textContent = `⚠ ${result.error}`;
        statusEl.className = "adv-query-status adv-query-err";
    }
}

function setIndicatorQueryText(text) {
    const box = document.getElementById("f_indicator_query");
    if (box) box.value = text || "";
    validateAndShowIndicatorQuery();
}
function getIndicatorQueryText() {
    const box = document.getElementById("f_indicator_query");
    return box ? box.value.trim() : "";
}
function clearIndicatorQuery() {
    setIndicatorQueryText("");
    applyFilters();
}

// Call this AFTER the regular filter pass (and after the advanced-query
// block), on the already-narrowed array, in BOTH applyFilters() and
// runFilterState() — see the two call-site snippets below.
function applyIndicatorQueryFilter(rows) {
    if (!isIndicatorQueryEnabled() || !indicatorEngineReady) return rows;
    const text = getIndicatorQueryText();
    if (!text) return rows;

    let predicate;
    try {
        predicate = IndicatorQuery.compileIndicatorQuery(text, { getOHLCVSeries, getIndicatorSeries });
    } catch {
        return rows; // invalid mid-typing — don't nuke the result set
    }
    if (!predicate) return rows;
    return rows.filter((row) => predicate(row["ISIN"]));
}

/* ---- Call-site snippet for applyFilters() in index.html ----
   Add right after the existing advEnabled/advText block (~line 15654),
   before the `if (callRenderPage) {` line:

     if (gc("f_indicator_enabled") && gv("f_indicator_query").trim()) {
         filteredData = applyIndicatorQueryFilter(filteredData);
     }

   ---- Call-site snippet for runFilterState() in index.html ----
   Add right after the existing adv-query block (~line 20090), replacing
   the final `return results;`:

     let finalResults = results;
     if (gbool("f_adv_enabled") && get("f_adv_query").trim()) {
         try {
             const advPred = advGetPredicate(get("f_adv_query"));
             if (advPred) finalResults = finalResults.filter(advPred);
         } catch (e) { console.warn("Advanced query in saved search failed:", e.message); }
     }
     if (gbool("f_indicator_enabled") && get("f_indicator_query").trim()) {
         finalResults = applyIndicatorQueryFilter(finalResults);
     }
     return finalResults;
*/

// ---------------------------------------------------------------------------
// 6. FILTER_FIELDS registration — this alone gives the indicator query
//    saved-search capture/restore AND JSON export/import for free, via the
//    exact same generic FILTER_FIELDS loop that already handles f_adv_query
//    (see captureFilters()/restoreFilters() in index.html). Add these two
//    lines into the FILTER_FIELDS array declaration:
//
//      { id: "f_indicator_enabled", type: "check" },
//      { id: "f_indicator_query", type: "text" },
//
//    And in restoreFilters(), right after the existing
//    `advSyncBuilderFromQuery(...); advValidateQuery();` lines, add:
//
//      handleRestoredIndicatorQuery(state.f_indicator_query || "");
// ---------------------------------------------------------------------------
function handleRestoredIndicatorQuery(text) {
    if (!text) return;
    if (indicatorEngineReady) {
        setIndicatorQueryText(text);
    } else {
        pendingRestoredIndicatorQuery = text;
        const statusEl = document.getElementById("indicatorQueryStatus");
        if (statusEl) {
            statusEl.textContent = isIndicatorQueryEnabled()
                ? "⏳ Pending — waiting for indicator engine"
                : "Saved, but Advance Indicator Query is currently disabled in Settings";
        }
    }
}

// ---------------------------------------------------------------------------
// 7. Boot + re-trigger on data reload / chart-settings change
// ---------------------------------------------------------------------------
window.addEventListener("load", () => {
    requestAnimationFrame(() => {
        if (isIndicatorQueryEnabled()) startIndicatorEngine();
        else setIndicatorUIState("disabled", null);
    });
});

// If CURRENT_DATA_DATE changes (new day's data loaded without a full page
// reload — e.g. an in-app refresh flow), the worker's cached results are for
// the wrong day and must be recomputed. Call this from wherever loadData()
// already detects a data-date change.
function onDataDateChanged() {
    if (isIndicatorQueryEnabled()) restartIndicatorEngine();
}

// Hook already exists in index.html's saveChartSettings():
//   if (typeof window.onChartSettingsSaved === "function") window.onChartSettingsSaved(oldSettings, settings);
// Wire it here so enabling/changing a chart indicator re-triggers the worker
// with the updated enabled-indicator-key set.
window.onChartSettingsSaved = function (oldSettings, newSettings) {
    if (isIndicatorQueryEnabled()) restartIndicatorEngine();
};

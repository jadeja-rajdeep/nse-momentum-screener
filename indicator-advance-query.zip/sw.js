// NSE Momentum Screener — Service Worker
// Bump CACHE_VERSION whenever you update index.html or any static asset.
//
// m.json strategy: this SW always fetches m.json fresh from network and
// updates DATA_CACHE on every successful response (cache is a fallback for
// offline use). The PAGE (index.html) has a separate, faster optimization:
// before even calling fetch(), it checks if today's date matches the last
// successfully-loaded date (stored in localStorage) and, if so, reads
// m.json directly out of this same DATA_CACHE — skipping the network
// request entirely and saving the ~4MB download on repeat same-day visits.
// Keep DATA_CACHE's name in sync with DATA_CACHE_NAME in index.html.
const CACHE_VERSION = "nse-screener-v100"; // bumped: added indicator-query files
const DATA_CACHE = "nse-screener-data-v1";

// Per-ISIN chart JSON (data/chart/{isin}.json) gets its own cache, kept
// separate from DATA_CACHE so it can be bulk-purged independently. These
// are cache-first (fast repeat opens) rather than network-first like
// m.json, because the page (index.html) purges this whole cache the
// moment tryLoadFromCacheIfFresh() decides the day's data is stale —
// so a stale entry never lingers past that point, and we don't pay a
// network round-trip on every single chart open in between.
// Keep this name in sync with CHART_CACHE_NAME in index.html.
const CHART_CACHE = "nse-screener-chart-v1";
const FINANCIAL_CACHE = "nse-screener-financial-v1";

// Fonts (and the CSS that declares them) rarely change and are identical
// across app versions, so they get their own cache that is NEVER deleted
// during activate's version-bump cleanup — a deploy shouldn't force
// re-downloading Bootstrap/Google Fonts from the CDN again.
const FONT_CACHE = "nse-screener-fonts-v1";
const FONT_HOSTS = ["fonts.googleapis.com", "fonts.gstatic.com", "cdn.jsdelivr.net"];

const STATIC_ASSETS = [
    "./",
    "./index.html",
    "./assets/css/mobile.css",
    "./assets/img/og-image.png",
    "./assets/img/favicon.svg",
    "./assets/img/favicon-32.png",
    "./assets/img/favicon.png",
    "./assets/img/icon-192.png",
    "./assets/img/icon-512.png",
    "./assets/img/badge-96.png",
    "./assets/audio/nse_screener_alert.wav",
    "./helper/indicator-db.js",
    "./helper/alert.js",
    "./helper/alert-worker.js",
    "./helper/indicator-calculators.js",
    "./helper/indicator-worker.js",
    "./helper/indicator-query.js",
    "./helper/indicator-query-ui.js"
];

// Assets that should always be served whole, ignoring any Range header
// the browser attaches (e.g. <audio preload="auto"> issuing byte-range
// requests) — Range requests get 206 responses from the network, and
// 206s can't be stored via cache.put(). Stripping Range here means we
// always deal in plain 200 responses, so this file gets cached once at
// install time and reliably served from cache on every later request.
const NO_RANGE_ASSETS = ["./assets/audio/nse_screener_alert.wav"];

// The Bootstrap CSS + Google Fonts CSS URLs, precached into FONT_CACHE at
// install time. The actual .woff2 files referenced by that CSS have
// versioned/hashed filenames that can change without notice, so we don't
// hardcode them here — they're picked up and cached automatically the
// first time the browser requests them (see the fetch handler below),
// and then persist in FONT_CACHE across future deploys.
const FONT_ASSETS = [
    "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css",
    "https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Sora:wght@400;600;700&display=swap",
    "https://unpkg.com/lightweight-charts/dist/lightweight-charts.standalone.production.js"
];

const LIVE_URL_HOSTS = [
  "nse-momentum-screener-api.vercel.app"
];

// ── Message: allow page to trigger SW update ─────────────────────────────────
self.addEventListener("message", (event) => {
    if (event.data?.type === "SKIP_WAITING") self.skipWaiting();
});

// ── Install: pre-cache all static assets ────────────────────────────────────
self.addEventListener("install", (event) => {
    event.waitUntil(
        Promise.all([
            caches.open(CACHE_VERSION).then((cache) => {
                // Cache what we can; don't fail install if an asset misses
                return Promise.allSettled(
                    STATIC_ASSETS.map((url) =>
                        cache
                            .add(url)
                            .catch(() =>
                                console.warn("[SW] Could not cache:", url),
                            ),
                    ),
                );
            }),
            caches.open(FONT_CACHE).then((cache) => {
                return Promise.allSettled(
                    FONT_ASSETS.map((url) =>
                        cache
                            .add(url)
                            .catch(() =>
                                console.warn("[SW] Could not cache font asset:", url),
                            ),
                    ),
                );
            }),
        ]).then(() => self.skipWaiting()),
    );
});

// ── Activate: delete old cache versions ─────────────────────────────────────
self.addEventListener("activate", (event) => {
    event.waitUntil(
        caches
            .keys()
            .then((keys) =>
                Promise.all(
                    keys
                        .filter(
                            (k) =>
                                k !== CACHE_VERSION &&
                                k !== DATA_CACHE &&
                                k !== FONT_CACHE &&
                                k !== CHART_CACHE &&
                                k !== FINANCIAL_CACHE
                        )
                        .map((k) => {
                            console.log("[SW] Deleting old cache:", k);
                            return caches.delete(k);
                        }),
                ),
            )
            .then(() => self.clients.claim()),
    );
});

// ── Fetch: route requests by strategy ───────────────────────────────────────
self.addEventListener("fetch", (event) => {
    const url = new URL(event.request.url);

    // Ignore unsupported schemes
    if (url.protocol !== "http:" && url.protocol !== "https:") {
        return;
    }

    // m.json → Network-first, fall back to stale cache
    if (url.pathname.endsWith("m.json")) {
        event.respondWith(networkFirstData(event.request));
        return;
    }

    // Per-ISIN chart JSON → Cache-first into its own CHART_CACHE. Freshness
    // is NOT handled here — index.html purges CHART_CACHE entirely as soon
    // as it detects the day's data has moved on (see tryLoadFromCacheIfFresh
    // in index.html), so whatever's cached here is trusted as-is.
    if (url.pathname.includes("/data/chart/") && url.pathname.endsWith(".json")) {
        event.respondWith(cacheFirst(event.request, CHART_CACHE));
        return;
    }else if (url.pathname.includes("/data/financial/") && url.pathname.endsWith(".json")) {
        event.respondWith(cacheFirst(event.request, FINANCIAL_CACHE));
        return;
    }

    // Bootstrap CSS, Google Fonts CSS, and the .woff2 files it references
    // → Cache-first into FONT_CACHE, which survives app version bumps.
    if (FONT_HOSTS.includes(url.hostname)) {
        event.respondWith(cacheFirst(event.request, FONT_CACHE));
        return;
    }

    //ALL LIVE API DATA HOST SERVE NETWORK FIRST.
    if (LIVE_URL_HOSTS.includes(url.hostname)) {
        event.respondWith(networkFirstData(event.request));
        return;
    }

    if (NO_RANGE_ASSETS.some((path) => url.pathname.endsWith(path))) {
        event.respondWith(cacheFirstNoRange(event.request, CACHE_VERSION));
        return;
    }

    // Everything else → Cache-first, fall back to network
    event.respondWith(cacheFirst(event.request, CACHE_VERSION));
});

// Network-first: try fresh, update cache, fall back to stale on error
async function networkFirstData(request) {
    const cache = await caches.open(DATA_CACHE);
    try {
        const response = await fetch(request, { cache: "no-store" });
        if (response.ok) {
            cache.put(request, response.clone());
        }
        return response;
    } catch {
        const cached = await cache.match(request);
        if (cached) {
            console.log("[SW] Offline – serving stale m.json from cache");
            return cached;
        }
        return new Response(
            JSON.stringify([
                {
                    type: "error",
                    message: "Offline and no cached data available.",
                },
            ]),
            { headers: { "Content-Type": "application/json" } },
        );
    }
}

// Cache-first: serve from cache instantly, fall back to network + cache
async function cacheFirst(request, cacheName = CACHE_VERSION) {
    const cache = await caches.open(cacheName);
    const cached = await cache.match(request);

    if (cached) return cached;

    try {
        const response = await fetch(request);

        // Only cache valid http/https responses. Cross-origin requests made
        // by the browser itself (e.g. the <link> tags for the font CSS and
        // the .woff2 files that CSS references) are fetched in "no-cors"
        // mode and come back as opaque responses — status 0, response.ok
        // is always false for these even on success — so we explicitly
        // allow type "opaque" through as well, or fonts would never
        // actually get cached here.
        // Range/partial responses (206) can't be stored in the Cache API and
        // will throw if you try — e.g. Range requests for the alert .wav file
        // (see alert.js's `new Audio(...).preload = 'auto'`). Let those pass
        // straight through without attempting to cache them.
        const cacheable =
            (response.ok || response.type === "opaque") && response.status !== 206;
        if (cacheable && request.url.startsWith("http")) {
            await cache.put(request, response.clone());
        }

        return response;
    } catch {
        return new Response("Offline", {
            status: 503,
            statusText: "Service Unavailable",
        });
    }
}

// Same as cacheFirst(), but rebuilds the request without a Range header
// first, so we always deal in whole-file 200 responses.
async function cacheFirstNoRange(request, cacheName = CACHE_VERSION) {
    if (request.headers.has("range")) {
        request = new Request(request.url, {
            method: "GET",
            headers: new Headers(
                [...request.headers].filter(([k]) => k.toLowerCase() !== "range")
            ),
        });
    }
    return cacheFirst(request, cacheName);
}

/* ============================================================================
   indicator-worker.js — background computation for the Indicator Advance
   Query feature.
   ----------------------------------------------------------------------------
   Started once, right after full page load (window 'load' + requestAnimationFrame),
   ONLY if the "advancedIndicatorQueryEnabled" setting is on.

   Message in:

     postMessage({
       type: "COMPUTE_INDICATORS",
       requestId: <number>,
       isins: ["INE...", ...],
       chartBaseUrl: "<absolute URL up to and including 'data/chart/'>",
       enabledIndicatorKeys: ["ema_50_close", "afh_60", "pivottrendline_20_high", ...],
       dataDate: "2026-09-26"
     })

   The worker fetches each stock's own `${chartBaseUrl}${isin}.json` itself
   (same URL shape the chart modal already fetches, same service-worker
   CHART_CACHE cache-first route already handles it) — candle data is NOT
   shipped through postMessage, since structured-cloning ~2000 stocks' full
   OHLCV history from the main thread would be far more expensive than just
   letting the worker fetch it directly.

   enabledIndicatorKeys are CANONICAL cache keys (see indicator-calculators.js
   header) — exactly the same key strings the chart-rendering code already
   uses, so a key computed here is instantly reused when a chart opens, and
   vice versa (checked via IndicatorCacheDB.get() before recomputing, same
   pattern the chart code already follows).

   Messages out:
     { type: "PROGRESS", requestId, done, total }
     { type: "DONE", requestId, keys: string[], count, errors: string[] }
     { type: "ERROR", requestId, error }
   ========================================================================= */

importScripts("./indicator-db.js");           // exposes self.IndicatorCacheDB
importScripts("./indicator-calculators.js");  // exposes self.IndicatorCalculators

const { computeIndicatorRaw } = self.IndicatorCalculators;

const YIELD_EVERY_N_STOCKS = 25;
const FETCH_CONCURRENCY = 6; // small pool, avoid hammering the network/cache all at once

self.onmessage = async function (e) {
    const msg = e.data || {};
    if (msg.type !== "COMPUTE_INDICATORS") return;
    const requestId = msg.requestId;

    try {
        const { isins, chartBaseUrl, enabledIndicatorKeys, dataDate } = msg;

        if (!Array.isArray(isins) || !isins.length || !Array.isArray(enabledIndicatorKeys) || !enabledIndicatorKeys.length) {
            self.postMessage({ type: "DONE", requestId, keys: [], count: 0, errors: [] });
            return;
        }

        const keySet = new Set();
        const errors = [];
        let done = 0;

        async function processOne(isin) {
            let candles;
            try {
                const res = await fetch(`${chartBaseUrl}${isin}.json`, { cache: "force-cache" });
                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                candles = await res.json();
            } catch (err) {
                errors.push(`${isin}: chart fetch failed — ${(err && err.message) || err}`);
                return;
            }
            if (!Array.isArray(candles) || !candles.length) return;

            for (const key of enabledIndicatorKeys) {
                try {
                    let raw = await IndicatorCacheDB.get(isin, key, dataDate);
                    if (!raw) {
                        raw = computeIndicatorRaw(key, candles);
                        if (raw) await IndicatorCacheDB.set(isin, key, dataDate, raw);
                    }
                    if (raw) keySet.add(key);
                } catch (err) {
                    errors.push(`${isin} / ${key}: ${(err && err.message) || err}`);
                }
            }
        }

        // Small worker-pool over the ISIN list so we don't fire ~2000
        // concurrent fetches at once.
        let cursor = 0;
        async function worker() {
            while (cursor < isins.length) {
                const isin = isins[cursor++];
                await processOne(isin);
                done++;
                if (done % YIELD_EVERY_N_STOCKS === 0) {
                    self.postMessage({ type: "PROGRESS", requestId, done, total: isins.length });
                }
            }
        }
        await Promise.all(Array.from({ length: FETCH_CONCURRENCY }, worker));

        self.postMessage({ type: "DONE", requestId, keys: [...keySet], count: isins.length, errors });
    } catch (err) {
        self.postMessage({ type: "ERROR", requestId, error: (err && err.message) || String(err) });
    }
};
